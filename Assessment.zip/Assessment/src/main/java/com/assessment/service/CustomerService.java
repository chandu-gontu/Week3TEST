package com.assessment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assessment.dao.CustomerDao;
import com.assessment.model.Customer;

import jakarta.transaction.Transactional;

@Transactional
@Service
public class CustomerService {
	@Autowired
	CustomerDao customerDao;
	public String addCustomer(Customer customer) {
		customerDao.save(customer);
		return "Added";
	}
	
	public List<Customer> getAllCustomers(){
		List<Customer> customerList = customerDao.findAll();
		return customerList;
	}
	
	public Customer updateCustomer(Integer cid,Customer customer) {
		Customer c=customerDao.findById(cid).get();
		if(c!=null)
			c.setEmail(customer.getEmail());
		return customerDao.findById(cid).get();
		
	}
	
	public Customer deleteCustomer(Integer cid) {
		Customer c=customerDao.findById(cid).get();
		if(c!=null)
			customerDao.deleteById(cid);
		return c;
	}

}
